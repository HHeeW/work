import{userRouter} from 'next/router'

const router = userRouter()