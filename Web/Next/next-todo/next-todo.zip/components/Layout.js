import React from 'react'

const Layout = () => {
  return (
    <div>
        <h1>제목: NextBoard1</h1>
        <p>상세내용</p>
    </div>
  )
}

export default Layout