import React from 'react'

const Footer = () => {
  return (
    <div styled={{backgroundColor: "black", color: "white"}}>
        Footer 영역
    </div>
  )
}

export default Footer