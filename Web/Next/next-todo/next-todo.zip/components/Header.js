import React from 'react'

const Header = () => {
  return (
    <div>
        <a href='#'>홈</a>
        <a href='#'>게시판</a>
    </div>
  )
}

export default Header